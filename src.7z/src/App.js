import React,{Component} from "react";
import axios from "axios";
class demo extends Component{
constructor(){
super();
this.state={
demo:null
}
}
componentDidMount(){
axios.get("https://jsonplaceholder.typicode.com/posts/1",{}).then((sample)=>{
this.setState({
demo:sample.data
});
}).catch((error)=>{
alert("There is an error in API call.");
});
}
render(){
return(
this.state.demo!=null &&
<div>
<h2>{this.state.demo.title}</h2>
<p>{this.state.demo.body}</p>
</div>
);
}
}  
export default demo;